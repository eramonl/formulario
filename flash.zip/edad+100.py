nombre = input("Como te llamas")
edad = int(input("cuantos años tienes?"))
año = 2023-edad
cien = str(año+100)
print("Hola "+ nombre + " El año que cumpliras 100 años sera el año " + cien)