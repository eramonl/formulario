numero = int(input("Dame un numero"))
if (numero%2) == 0:
    print("Es par")
else:
    print("Es impar")